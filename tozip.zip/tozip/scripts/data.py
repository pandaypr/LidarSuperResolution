#!/usr/bin/env python
import os
import time
#import thread
import math
#import cv2
import numpy as np
import tensorflow as tf
# Global Variables
#LiDAR setttings, Scala2:
image_rows_low = 16 # 8, 16, 32
image_rows_high = 120 # 16, 32, 64
ang_res_x = 120.0/float(375) # horizontal resolution, Image columns=375 for Scala3
ang_res_y = 10/float(image_rows_high-1) # vertical resolution
ang_start_y = 5.0 # bottom beam angle
sensor_noise = 0.03
max_range = 200.0
min_range = 0.5
image_cols_low = 748    #633 + 115= 748
channel_num = 1
#upscaling_factor = int(image_rows_high / image_rows_low)
print('#'*50)
print('Input image resolution:   {} by {}'.format(image_rows_low, 633))
print('Output image resolution:  {} by {}'.format(image_rows_high, 375))
print('Upscaling ratio:          {}'.format(7.5,0.59241))


normalize_ratio = 100.0
print('#'*50)
print('Sensor minimum range:     {}'.format(min_range))
print('Sensor maximum range:     {}'.format(max_range))
print('Sensor view angle:        {} to {}'.format(-ang_start_y, -ang_start_y + ang_res_y*(image_rows_high-1)))
print('Range normalize ratio:    {}'.format(normalize_ratio))

# home dir
project_name = 'SuperResolution'
home_dir = os.path.expanduser('~')
root_dir = os.path.join(home_dir, 'Documents', project_name)
# Check Path exists
path_lists = [root_dir]
for folder_name in path_lists:
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

# training & testing data
training_data_Scala2 = os.path.join(home_dir, 'Documents', project_name,'dataset','train', 'scala2', "data.npy")
training_data_Scala3 = os.path.join(home_dir, 'Documents', project_name,'dataset','train',  'scala3', "data.npy")
testing_data_Scala2 =os.path.join(home_dir, 'Documents', project_name, 'dataset', 'test', 'scala2',  'data' + '.npy')
testing_data_Scala3 =os.path.join(home_dir, 'Documents', project_name, 'dataset', 'test','scala3',  'data' + '.npy')
print('#'*50)
print('Training data-set Scala2:        {} '.format(training_data_Scala2))
print('Testing data-set Scala2:         {}'.format(testing_data_Scala2))
print('Training data-set Scala3:        {} '.format(training_data_Scala3))
print('Testing data-set Scala3:         {}'.format(testing_data_Scala3))


def pre_processing_raw_data(data_set_name):
    # load data
    full_res_data = np.load(data_set_name)
    full_res_data = full_res_data.astype(np.float32, copy=True)
    

    if data_set_name == training_data_Scala2:
        Rows= tf.ones([full_res_data.shape[0], 2, 633, 1])
        Cols= tf.ones([full_res_data.shape[0], 18, 115, 1])
        Row_padded =tf.concat([full_res_data,Rows],axis=1)
        full_res_data = tf.concat([Row_padded,Cols],axis=2)
        full_res_data = np.asarray(full_res_data)
        print('add noise ...')
        noise = np.random.normal(0, sensor_noise, full_res_data.shape) # mu, sigma, size
        noise[full_res_data == 0] = 0
        full_res_data = full_res_data + noise


    # apply sensor range limit
    full_res_data[full_res_data > max_range] = 0
    full_res_data[full_res_data < min_range] = 0

    # normalize data
    full_res_data = full_res_data / normalize_ratio

    return full_res_data


def load_train_data():
    train_data = pre_processing_raw_data(training_data_Scala3)
    train_data_input = pre_processing_raw_data(training_data_Scala2)
    return train_data_input, train_data

def load_test_data():
    test_data = pre_processing_raw_data(testing_data_Scala3)
    test_data_input = pre_processing_raw_data(testing_data_Scala2)
    return test_data_input, test_data

if __name__=='__main__':
    
    pass